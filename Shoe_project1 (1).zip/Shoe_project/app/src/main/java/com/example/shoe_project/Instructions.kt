package com.example.shoe_project

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.navigation.NavController
import androidx.navigation.findNavController
import com.example.shoe_project.databinding.ActivityMainBinding
import com.example.shoe_project.databinding.InstructionBinding
//import com.example.shoe_project.databinding.WelcomeBinding

class Instructions: Fragment() {
    lateinit var binding: ActivityMainBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val binding: InstructionBinding = DataBindingUtil.inflate(
            inflater, R.layout.instruction, container, false)
        binding.button1.setOnClickListener{
         it.findNavController().navigate(InstructionsDirections.actionInstruction0ToDescription0())
        }
        binding.button2.setOnClickListener{
            it.findNavController().navigate(InstructionsDirections.actionInstruction0ToDescription0())
        }

        return binding.root
    }
}