package com.example.shoe_project

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import com.example.shoe_project.databinding.DescriptionBinding
import com.example.shoe_project.databinding.DetailedBinding

class Detailed: Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding: DetailedBinding = DataBindingUtil.inflate(
            inflater, R.layout.detailed, container, false)
        binding.butt.setOnClickListener{
            it.findNavController().navigate(DetailedDirections.actionDetailed0ToNeuDetailed())
        }

        return binding.root }



}