package com.example.shoe_project

import android.os.Bundle
import android.view.*
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.navigation.ui.NavigationUI
import com.example.shoe_project.databinding.DescriptionBinding
import com.example.shoe_project.databinding.DetailedBinding
import com.example.shoe_project.databinding.ListedshoesBinding
import kotlin.collections.MutableMap as MutableMap

class Listed_Shoes_0: Fragment() {

    lateinit var a_0:Shoes

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        a_0= ViewModelProvider(this).get(Shoes::class.java)

        val binding: ListedshoesBinding = DataBindingUtil.inflate(
            inflater, R.layout.listedshoes, container, false)
        setHasOptionsMenu(true)
        binding.arrayenter.text=array_to_string_detailed(a_0.a)
        binding.adding0.setOnClickListener{
            a_0.add_to_list(binding.edit1.text.toString(),binding.edit2.text.toString())
            binding.arrayenter.text=array_to_string_detailed(a_0.a)
        }


        return binding.root }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater?.inflate(R.menu.menu, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return NavigationUI.onNavDestinationSelected(item, requireView().findNavController())
                || super.onOptionsItemSelected(item)
    }

    /*fun to_String_keys(Map:MutableMap<String,String>):String{
        var neu:String=""
        for(value in Map.keys) neu=neu + Map[value] +"\n"
        return neu
    }
    fun to_String(Map:MutableMap<String,String>):String{
        var neu:String=""
        for(value in Map.keys) neu=neu+value+" "+ Map[value] +"\n"
        return neu
    }  */

    fun array_to_string_detailed(arr:MutableList<String>):String{
        var placeholder:String=""
        for(i in 0 until (arr.size-1) step 2){
            placeholder+=arr[i]+" "+arr[i+1] + "\n"
        }
        return placeholder

    }
    fun array_to_string_nodet(arr:MutableList<String>):String{
        var placeholder:String=""
        for(i in 0 until (arr.size-1) step 2){
            placeholder+=arr[i]+ "\n"
        }
        return placeholder

    }



    }