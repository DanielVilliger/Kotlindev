package com.example.shoe_project

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import com.example.shoe_project.databinding.ActivityMainBinding
import com.example.shoe_project.databinding.DescriptionBinding
import com.example.shoe_project.databinding.InstructionBinding

class Description: Fragment() {
    //lateinit var binding: ActivityMainBinding
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding: DescriptionBinding = DataBindingUtil.inflate(
            inflater, R.layout.description, container, false)
        binding.button00.setOnClickListener{
            it.findNavController().navigate(DescriptionDirections.actionDescription0ToDetailed0())
        }

        return binding.root
    }
}