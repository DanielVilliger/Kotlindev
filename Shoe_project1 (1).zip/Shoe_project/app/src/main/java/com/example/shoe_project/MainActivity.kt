package com.example.shoe_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import androidx.databinding.DataBindingUtil.setContentView
import com.example.shoe_project.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var bindings:ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        bindings= DataBindingUtil.setContentView(this,R.layout.activity_main)

    }
}