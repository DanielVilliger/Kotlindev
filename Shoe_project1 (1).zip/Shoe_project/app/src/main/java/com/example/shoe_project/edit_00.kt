package com.example.shoe_project

data class Edit_0(var informa:String)
