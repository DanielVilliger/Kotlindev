package com.example.shoe_project

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import com.example.shoe_project.databinding.DescriptionBinding
import com.example.shoe_project.databinding.NeudetailedBinding

class NeuDetailed: Fragment() {
    var a = mutableListOf<String>(
        "D12",
        "D11",
        "D10",
        "D9",
        "D8",
        "D7",
        "D6",
        "D5",
        "D4",
        "D3",
        "D2",
        "D1"
    )
    var ed:Edit_0= Edit_0(list_to_string(a))
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding: NeudetailedBinding = DataBindingUtil.inflate(
            inflater, R.layout.neudetailed, container, false)
        //binding.shoesnotdetailed.text=list_to_string(a)
        binding.editieren=ed
        binding.next0.setOnClickListener{
            it.findNavController().navigate(NeuDetailedDirections.actionNeuDetailedToListed0())
        }

        return binding.root
    }

    fun list_to_string(a:MutableList<String>):String{
        var placeholder=""
        for(value in a) {
            placeholder+=value+"\n"
        }
        return placeholder

    }
}