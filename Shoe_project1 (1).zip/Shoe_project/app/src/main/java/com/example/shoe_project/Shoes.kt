package com.example.shoe_project

import androidx.lifecycle.ViewModel

class Shoes(): ViewModel() {

    var a = mutableListOf<String>(
          "D12", "size: 12 company:adidas description: brandnew"
         ,"D11", "size: 12 company:adidas description: brandnew"
         ,"D10", "size: 12 company:adidas description: brandnew"
         ,"D9", "size: 12 company:adidas description: brandnew"
         ,"D8", "size: 12 company:adidas description: brandnew"
         ,"D7", "size: 12 company:adidas description: brandnew"
         ,"D6", "size: 12 company:adidas description: brandnew"
         ,"D5", "size: 12 company:adidas description: brandnew"
         ,"D4", "size: 12 company:adidas description: brandnew"
         ,"D3", "size: 12 company:adidas description: brandnew"
         ,"D2", "size: 12 company:adidas description: brandnew"
         ,"D1", "size: 12 company:adidas description: brandnew"
    )
     /*data class Shoe(var name: String, var size: Double, var company: String, var description: String,
                     val images: List<String> = mutableListOf()) : Parcelable */
 fun add_to_list(value:String, value_0:String){
    a.add(value)
    a.add(value_0)
}
}